#!/bin/sh
SelectMAP A ./BEE7_EXT_9p8304.bin
./configure_rtm_revd_v2.py -f A -r 5,6,7,8,9,10,11,12,13,14,15,16 -s 9.8304
