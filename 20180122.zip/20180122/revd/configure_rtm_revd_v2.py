#!/usr/bin/python

import sys
import argparse
import re
import subprocess
import math
import os

FNULL = open(os.devnull, 'w')

# A0 refers to lanes 1-4, A1 refers to lanes 5-8, etc.
iic_addr_dict = {	'A0': '0x18', 'A1': '0x1A', 'A2': '0x22', 'A3': '0x1B',
					'B0': '0x20', 'B1': '0x23', 'B2': '0x1C', 'B3': '0x24',
					'C0': '0x19', 'C1': '0x1D', 'C2': '0x25', 'C3': '0x1E',
					'D0': '0x21', 'D1': '0x26', 'D2': '0x1F', 'D3': '0x27'}
					
line_rate_dict = { 	'10.3125': 'F6', '1.25': 'F6', 
					'2.4576': '36', '4.9152': '36', '9.8304': '36',
					'3.072': '46', '6.144': '46'}
					
#lanes are indexed from 1 based on numbering on RTM faceplate
all_FPGAs = ['A', 'B', 'C', 'D']
all_lanes = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16']

# First parse arguments for program
parser = argparse.ArgumentParser(description='RTM RevD configuration script')
parser.add_argument('-r', '--rtm', help='rtm lanes to set. Ex: 1,2,15,16')
parser.add_argument('-f', '--fpga', help='fpgas to set. Ex: A,B,C,D')
parser.add_argument('-s', '--speed', help='Custom or standard line rate. Standard Values include: 10.3125, 1.25, 9.8304, 4.9152, 2.4576, 6.144, 3.072')
parser.add_argument('-v', '--verbose', help='Prints out all I2C commands that are run', action='store_true')
parser.add_argument('-c', '--copper', help='Specifies the user is using copper cables. Sets retimer output settings to 3/3', action='store_true')
parser.add_argument('-n', '--nodfe', help='Turns off DFE for the specified lanes', action='store_true')

args = parser.parse_args()
	
if args.rtm:
	lanes = args.rtm.split(',')
else:
	lanes = all_lanes
			
if args.fpga:
	FPGA_list = args.fpga.split(',')
else:
	FPGA_list = all_FPGAs
	
if args.speed:
	line_rate = args.speed
else:
	line_rate = '10.3125'
	
if args.verbose:
	linux_shell = ''
else:
	linux_shell = ' &> /dev/null'
	
process = subprocess.Popen("which boardctl", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if(process.stdout.read() != ''):
	fw_command = 'boardctl'
	i2c_bus = '6'
	print('Detected ATCA3671')
else:
	fw_command = 'bee7control'
	i2c_bus = '0'
	print('Detected BEE7')

if __name__ == '__main__':
	try:
		# Set IIC switch on BEE7
		print 'Configuring RTM lanes...'
		if(fw_command == 'bee7control'):
			subprocess.call(['bee7control iic -t i -b 0 -a 0x70 -w 1 -v 0x08 ',linux_shell],shell=True)
		
		customLineRate = False
		if not line_rate in line_rate_dict.keys():
			customLineRate = True
			print 'Detected custom line rate of %s' % (line_rate)
			ppmVal = int(math.ceil(float(line_rate)*1280))
			if(ppmVal > 0x7FFF):
				raise Exception('ERROR! Line rate too high (%s)' % (line_rate))
			ppmValLSBs = ppmVal & 0x00FF
			ppmValMSBs = (ppmVal & 0xFF00) >> 8
			customLineRateLSBs = '%02X' % ppmValLSBs
			customLineRateMSBs = '%02X' % (ppmValMSBs | 0x80)
			
			#raise Exception('ERROR! Unrecognized lane rate: %s' % (line_rate))
		else:
			lane_reg_value = line_rate_dict[line_rate]
		
		for FPGA in FPGA_list:
			if not FPGA in all_FPGAs:
				raise Exception('ERROR! Unrecognized FPGA: %s' % (FPGA));
			for lane in lanes:
				if not lane in all_lanes:
					raise Exception('ERROR! Lane out of bounds: %s' % (lane))
				iic_addr = iic_addr_dict[FPGA + str(int((math.floor((int(lane)-1)/4))))]
				chan_sel_reg = str((int(lane)-1) % 4 + 4)
				
				try:
					# Channel read, channel write
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0xFF0',chan_sel_reg])
					subprocess.call(cmd +linux_shell,shell=True)
					
					# Enable DFE mode. Optimizes CTLE first and then sets DFE
					if args.nodfe:
						cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x1EE9'])
						subprocess.call(cmd+linux_shell,shell=True)
					else:
						cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x1EE1'])
						subprocess.call(cmd+linux_shell,shell=True)
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x3140'])
					subprocess.call(cmd+linux_shell,shell=True)
				except Exception as error:
					print ''
					print 'Unable to configure RTM! Is this a RevD RTM?'
					raise Exception('Bad IIC command, check that RTM is RevD.')
				
				# If copper, assume 1M cable and set output swing to 800mV and emphasis to 3
				if args.copper:
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x2D83'])
					subprocess.call(cmd+linux_shell,shell=True)
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x1513'])
					subprocess.call(cmd+linux_shell,shell=True)
				else: #For optical cables set output swing and emphasis to minimum
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x2D80'])
					subprocess.call(cmd+linux_shell,shell=True)
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x1510'])
					subprocess.call(cmd+linux_shell,shell=True)
				
				# Set speed detect of equalizer
				if(customLineRate):
					#Set VCO divider to 1
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x2FC6'])
					subprocess.call(cmd+linux_shell,shell=True)
					
					#Set frequency range detect = line_rate*1280. MSB of 0x61/0x63 should be set high
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x60', customLineRateLSBs])
					subprocess.call(cmd+linux_shell,shell=True)
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x62', customLineRateLSBs])
					subprocess.call(cmd+linux_shell,shell=True)
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x61', customLineRateMSBs])
					subprocess.call(cmd+linux_shell,shell=True)
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x63', customLineRateMSBs])
					subprocess.call(cmd+linux_shell,shell=True)
					
					#Set VCO tolerance range to maximum
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x64ff'])
					subprocess.call(cmd+linux_shell,shell=True)
				else:
					cmd = ''.join([fw_command, ' iic -t i -b ', i2c_bus, ' -a ', iic_addr, ' -w 2 -v 0x2F',lane_reg_value])
					subprocess.call(cmd+linux_shell,shell=True)
	except Exception as error:
		print ''
		print 'Failed to configure all RTM lanes!'
		print error
		print ''
	finally:
		# Clear IIC switch
		if(fw_command == 'bee7control'):
			subprocess.call(['bee7control iic -t i -b 0 -a 0x70 -w 1 -v 0x00 ', linux_shell],shell=True)
		print 'done'
		
