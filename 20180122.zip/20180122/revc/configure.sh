#!/bin/sh
# Copy additional software configuration into /etc
# This can be used for a persistent SSH key, for example,
# if one is placed at etc/dropbear/dropbear_rsa_host_key
#cp -r /media/card/etc/* /etc/.

#Setup python environment
ln -s /media/card/opt/python/bin/python /usr/bin/python

SelectMAP A ./BEE7_EXT_9p8304.bin
#configure retimer parameter for A
#RTM0~3,FPGA A
rtm64control rptr -f A -l 0x0001 -v 0 -d 0 -e 3
rtm64control rptr -f A -l 0x0002 -v 0 -d 0 -e 1
rtm64control rptr -f A -l 0x0004 -v 0 -d 0 -e 1
rtm64control rptr -f A -l 0x0008 -v 0 -d 0 -e 1
#QSFP,FPGA A
rtm64control rptr -f A -l 0x00f0 -v 0 -d 0 -e 0
rtm64control rptr -f A -l 0x0f00 -v 2 -d 0 -e 0
rtm64control rptr -f A -l 0xf000 -v 0 -d 0 -e 0

#configure retimer parameter for B
#RTM0~3,FPGA B
rtm64control rptr -f B -l 0x0001 -v 0 -d 0 -e 0
rtm64control rptr -f B -l 0x0002 -v 0 -d 0 -e 0
rtm64control rptr -f B -l 0x0004 -v 0 -d 0 -e 0
rtm64control rptr -f B -l 0x0008 -v 0 -d 0 -e 0
#QSFP,FPGA B
rtm64control rptr -f B -l 0x00f0 -v 0 -d 0 -e 0
rtm64control rptr -f B -l 0x0f00 -v 0 -d 0 -e 0
rtm64control rptr -f B -l 0xf000 -v 0 -d 0 -e 0

#configure retimer parameter for C
#RTM0~3,FPGA C
rtm64control rptr -f C -l 0x0001 -v 0 -d 0 -e 0
rtm64control rptr -f C -l 0x0002 -v 0 -d 0 -e 0
rtm64control rptr -f C -l 0x0004 -v 0 -d 0 -e 0
rtm64control rptr -f C -l 0x0008 -v 0 -d 0 -e 0
#QSFP,FPGA C
rtm64control rptr -f C -l 0x00f0 -v 0 -d 0 -e 1
rtm64control rptr -f C -l 0x0f00 -v 0 -d 0 -e 1
rtm64control rptr -f C -l 0xf000 -v 0 -d 0 -e 1

#configure retimer parameter for D
#RTM0~3,FPGA D
rtm64control rptr -f D -l 0x0001 -v 0 -d 0 -e 0
rtm64control rptr -f D -l 0x0002 -v 0 -d 0 -e 0
rtm64control rptr -f D -l 0x0004 -v 0 -d 0 -e 0
rtm64control rptr -f D -l 0x0008 -v 0 -d 0 -e 0
#QSFP,FPGA D
rtm64control rptr -f D -l 0x00f0 -v 0 -d 0 -e 2
rtm64control rptr -f D -l 0x0f00 -v 0 -d 0 -e 2
rtm64control rptr -f D -l 0xf000 -v 0 -d 0 -e 2
